from tractor import tractor

if __name__ == '__main__':
    tractor()
