required = lambda v: v is not None and v != ""
