import click


@click.group()
def remove():
    """Delete config commands"""

